﻿# Host: localhost  (Version: 5.5.15)
# Date: 2018-01-20 21:28:51
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "course_office"
#

DROP TABLE IF EXISTS `course_office`;
CREATE TABLE `course_office` (
  `course_id` varchar(64) NOT NULL,
  `office_id` varchar(64) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` smallint(6) DEFAULT '0',
  PRIMARY KEY (`course_id`,`office_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "course_office"
#

INSERT INTO `course_office` VALUES ('223a742b176b4aa68dba50c49b81dd84','1','2018-01-07 11:21:12','2018-01-07 11:21:12',0),('223a742b176b4aa68dba50c49b81dd84','2','2018-01-07 11:54:53','2018-01-07 11:21:12',0),('223a742b176b4aa68dba50c49b81dd84','3','2018-01-07 11:55:07','2018-01-07 11:21:12',0),('223a742b176b4aa68dba50c49b81dd84','4','2018-01-07 11:55:27','2018-01-07 11:21:12',0),('bee646f3d731496bb9a67e7684294670','100','2018-01-13 10:48:35','2018-01-13 10:48:35',0),('bee646f3d731496bb9a67e7684294670','101','2018-01-13 10:49:00','2018-01-13 10:49:00',0),('bee646f3d731496bb9a67e7684294670','102','2018-01-13 10:49:11','2018-01-13 10:49:00',0),('bee646f3d731496bb9a67e7684294670','103','2018-01-13 10:49:24','2018-01-13 10:49:00',0);
