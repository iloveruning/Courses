﻿# Host: localhost  (Version: 5.5.15)
# Date: 2018-01-20 21:30:48
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "teacher_picture"
#

DROP TABLE IF EXISTS `teacher_picture`;
CREATE TABLE `teacher_picture` (
  `teacher_id` varchar(64) NOT NULL,
  `picture_id` varchar(64) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(1) NOT NULL,
  PRIMARY KEY (`teacher_id`,`picture_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "teacher_picture"
#

