﻿# Host: localhost  (Version: 5.5.15)
# Date: 2018-01-20 21:31:42
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "video_picture"
#

DROP TABLE IF EXISTS `video_picture`;
CREATE TABLE `video_picture` (
  `video_id` varchar(64) NOT NULL DEFAULT '',
  `picture_id` varchar(64) NOT NULL DEFAULT '',
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(1) DEFAULT '0',
  PRIMARY KEY (`video_id`,`picture_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "video_picture"
#

INSERT INTO `video_picture` VALUES ('1','8','2018-01-13 16:09:47','2018-01-13 16:09:40',0),('111','8','2018-01-13 16:09:45','2018-01-13 16:09:40',0);
