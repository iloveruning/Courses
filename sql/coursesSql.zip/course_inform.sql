﻿# Host: localhost  (Version: 5.5.15)
# Date: 2018-01-20 21:28:38
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "course_inform"
#

DROP TABLE IF EXISTS `course_inform`;
CREATE TABLE `course_inform` (
  `course_id` varchar(64) NOT NULL,
  `inform_id` varchar(64) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(1) NOT NULL,
  PRIMARY KEY (`course_id`,`inform_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "course_inform"
#

