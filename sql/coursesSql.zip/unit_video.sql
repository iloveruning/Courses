﻿# Host: localhost  (Version: 5.5.15)
# Date: 2018-01-20 21:31:24
# Generator: MySQL-Front 5.3  (Build 4.269)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "unit_video"
#

DROP TABLE IF EXISTS `unit_video`;
CREATE TABLE `unit_video` (
  `unit_id` varchar(64) NOT NULL,
  `video_id` varchar(64) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(1) NOT NULL,
  PRIMARY KEY (`unit_id`,`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "unit_video"
#

INSERT INTO `unit_video` VALUES ('1','1','2018-01-11 14:41:36','2018-01-11 14:41:36',0),('glxxx11','111','2018-01-05 22:03:25','2018-01-05 22:03:25',0);
